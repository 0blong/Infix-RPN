#include "../hdr/infixtorpn.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

/** Infix2RPN * create(int outputToScreen)
*   in: infix - string containing the infix to be converted
*   in: outputToScreen - setup variable defining whether to output to screen
*   out: Infix2RPN - pointer to the structure containing the strings
*   Creates the Infix2RPN struct and initialises the char * members
*   Sets the infix variable in the struct
*   If the allocation of memory fails, returns an error
*   Sets up the output to screen setting
*   Calls for conversion of the infix string
*/
Infix2RPN * create(int outputToScreen)
{
  struct Infix2RPN * i2r = malloc(sizeof(struct Infix2RPN));
  if(i2r == NULL) 
  {
    printf("INSUFFICIENT MEMORY\n");
    exit(-1);
  }
  i2r->bOutputToScreen = outputToScreen;
  i2r->rpn = NULL;
  i2r->infix = NULL;
  return i2r;
}

/** Infix2RPN * convert(Infix * i2r, char * infix)
*   in: Infix * i2r - struct containing the strings
*   in: char * infix - string containing infix
*   out: Infix * - pointer to struct
*   Sets the infix string in the struct and initialises the rpn string 
*   Calls for conversion
*   Returns pointer to the struct
*/
Infix2RPN * convert(Infix2RPN * i2r, char * infix)
{
  i2r->infix = malloc((strlen(infix) + 1) * sizeof(char *));
  i2r->rpn = malloc(sizeof(char));
  if(i2r->rpn == NULL || i2r->infix == NULL)
  {
    printf("MALLOC FAIL\n");
    exit(-1);
  }

  strcpy(i2r->infix, infix);
  i2r->rpn[0] = '\0'; 

  i2r = iterate(i2r);

  return i2r;
}

/** Infix2RPN * iterate(Infix2RPN * i2r)
*   in: i2r - struct containing the strings
*   out: Infix2RPN - struct containing the strings
*   Iterates through the infix string converting to RPN on a char by char basis
*/
Infix2RPN * iterate(Infix2RPN * i2r)
{
  stack s;
  char x;
  int token;
  init(&s);
  
  int nLen = (int)strlen(i2r->infix);

  for(int i = 0; i < nLen; i++) {
    token = i2r->infix[i];
    if(isalnum(token)) {
      i2r->rpn = append(i2r->rpn, (char)token);
    }
    else {
      if(token == '(') {
	push(&s,'(');
      }
      else {
	if(token == ')') {
	  while((x=pop(&s))!='(') {
	    i2r->rpn = append(i2r->rpn, (char)x);
	  }
	}
	else {
	  while(priority(token) <= priority(top(&s)) && !empty(&s)) {
	    x=pop(&s);
	    i2r->rpn = append(i2r->rpn, (char)x);
	  }
	  push(&s,token);
	}
      }
    }
  } 
  while(!empty(&s))
  {
    x=pop(&s);
    i2r->rpn = append(i2r->rpn, (char)x);;
  }

  return i2r;
}

/** char * append(char * rpn, const char c)
*   in: rpn - the rpn string that is to be appended to
*   in: c - the character to be appended to the string
*   out: char * - the final string
*/
char * append(char * rpn, const char c)
{ 
  char * temp;
  int rpnLength = strlen(rpn);
  temp = realloc(rpn, rpnLength + 1);
  if(temp != NULL)
  {
    temp[rpnLength] = c;
    temp[rpnLength+1] = '\0';
    rpn = temp;
  }
  else
  {
    printf("INSUFFICIENT MEMORY\n");
    exit(-1);
  }
  return rpn;
}

/** char * getRPN(Infix2RPN * i2r)
*   in: i2r - pointer to the struct containing the strings
*   out: char * - the converted rpn string
*   Prints the infix and rpn to screen depending on the setup
*/
char * getRPN(Infix2RPN * i2r)
{
  if(i2r->bOutputToScreen == 1) 
  {
    printf("INFIX: %s;  RPN: %s\n", i2r->infix, i2r->rpn);
  }
  return i2r->rpn;
}

/** Infix2RPN * freeStrings(Infix2RPN * i2r)
*   in: i2r - struct containing the strings
*   out: Infix2RPN * struct containing the strings
*   Frees the memory allocated to the strings in the struct
*/
Infix2RPN * freeStrings(Infix2RPN * i2r)
{
  free(i2r->infix);
  i2r->infix = NULL;
  free(i2r->rpn);
  i2r->rpn = NULL;
  return i2r;
}

/** Infix2RPN freeStruct(Infix2RPN * i2r)
*   in: i2r - struct
*   out: i2r - struct
*   Frees the memory allocated to the struct
*/
Infix2RPN * freeStruct(Infix2RPN * i2r)
{
  free(i2r);
  return i2r;
}

/** int priority(char x)
*   in: char x - the character to be handled
*   out: int - the priority ranking of the character
*   Returns the priority scaling of the character in RPN terms
*/
int priority(char x)
{
   if(x == '(')
 return(0);
   if(x == '+')
 return (1);
   if(x == '-')
 return(2);
   if(x == '*')
 return(3);
   if(x == '/')
 return(4);
   if(x == '^')
 return(5);
   return(6);
}

/** void init(stack * s)
*   in: stack * s - stack symbols to
*   Initialises the stack for use
*/
void init(stack * s)
{
   s->top=-1;
}

/** int empty(stack * s)
*   in: stack * s - stack of characters
*   out: int - signal whether stack is empty
*   Returns 1 when stack is empty
*/
int empty(stack * s)
{
    if(s->top==-1)
 return(1);
    else 
 return(0);
}

/** int (stack * s)
*   in: stack * s - stack of characters
*   out: int - signal whether stack is full
*   Returns 1 when stack is full
*/
int full(stack * s)
{
    if(s->top==MAX-1)
 return(1);
    else 
 return(0);
}

/** void push(stack * s, char x)
*   in: stack * s - stack holding characters
*   in: char x - character to be added to stack
*   Pushes onto the stack one character
*/
void push(stack * s,char x)
{
  s->top=s->top+1;
  s->data[s->top]=x;
}

/** char pop(stack * s)
*   in: stack * s - stack of characters
*   out char - character from stack
*   Pops the top character from the stack and returns it
*/
char pop(stack * s)
{
   int x;
   x=s->data[s->top];
   s->top=s->top-1;
   return(x);
}

/** char top(stack * s)
*   in: stack * s - stack of characters
*   out: char - character from top of stack
*   Returns the value of the top character from the stack
*/
char top(stack * s)
{
   return(s->data[s->top]);
}
