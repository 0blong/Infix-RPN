#ifndef INFIXTORPN_H
#define INFIXTORPN_H

#define MAX 100

/** Infix2RPN
*   Structure to hold the input and output strings
*   char * members must be freed after use and can be re-used
*   int member set to 1 will output the contents of the char * to screen
*/
typedef struct Infix2RPN
{
  int bOutputToScreen;	// indicates whether to output the char * to screen
  char * infix;		// variable length string to hold the input infix
  char * rpn;		// variable length string to hold the converted rpn
}Infix2RPN;

/** typedef struct stack
*   stack to push & pop operators as they are iterated through
*/
typedef struct stack
{
 int data[MAX];		// operator storage
 int top;		// top character index
}stack;

Infix2RPN * create(int);
Infix2RPN * convert(Infix2RPN *, char *);
Infix2RPN * iterate(Infix2RPN *);
char * append(char *, const char);
char * getRPN(Infix2RPN *);
Infix2RPN * freeStrings(Infix2RPN *);
Infix2RPN * freeStruct(Infix2RPN *);  
int priority(char);
void init(stack *);
int empty(stack *);
int full(stack *);
char pop(stack *);
void push(stack *,char);
char top(stack *);

#endif /* INFIXTORPN_H */
