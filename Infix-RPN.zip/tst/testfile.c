#include <stdio.h> 
#include <stdlib.h>
#include <check.h>
#include "../project/hdr/infixtorpn.h"
 
 START_TEST(infixToRPN)
 {
     printf("START TEST\n");

     //create an instance of an Infix2RPN struct in memory
     Infix2RPN * i2r;
     //initialise the struct and the strings it contains
     //pass in a variable 0 = do not output to screen
     i2r = create(1);

     //Convert an infix string
     i2r = convert(i2r, "a+b");
     //Get result rpn from the struct
     ck_assert_str_eq(getRPN(i2r), "ab+");
     //Free the memory allocated to the strings in the struct
     i2r = freeStrings(i2r);

     //re-use the struct
     i2r = convert(i2r, "(a+b)-c");
     ck_assert_str_eq(getRPN(i2r), "ab+c-");
     i2r = freeStrings(i2r);     

     i2r = convert(i2r, "l/m^n*o-p");
     ck_assert_str_eq(getRPN(i2r), "lmn^/o*p-");
     i2r = freeStrings(i2r);     

     i2r = convert(i2r, "((v/w)^x)*(y-z)");
     ck_assert_str_eq(getRPN(i2r), "vw/x^yz-*");
     i2r = freeStrings(i2r);     

     i2r = convert(i2r, "v/w^x*y-z");
     ck_assert_str_eq(getRPN(i2r), "vwx^/y*z-");
     i2r = freeStrings(i2r);  

     //free the memory allocated to the struct
     i2r = freeStruct(i2r);

     printf("END TEST\n");
 }
 END_TEST

 int main(void)
 {
    Suite *s1 = suite_create("Core");
    TCase *tc1_1 = tcase_create("Core");
    SRunner *sr = srunner_create(s1);
    int nf;

    suite_add_tcase(s1, tc1_1);
    tcase_add_test(tc1_1, infixToRPN);

    srunner_run_all(sr, CK_ENV);
    nf = srunner_ntests_failed(sr);
    srunner_free(sr);

    return nf == 0 ? 0 : 1;
 }
